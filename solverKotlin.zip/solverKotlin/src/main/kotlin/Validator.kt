import java.util.*

class Validator {
    /**
     * checks if the input is valid (only letters, no repeating letters, size of 12, correct format)
     * @param input string of unique characters in the format xxx,xxx,xxx,xxx
     * @return boolean that says whether the input fits the format or not
     */
    fun validateInput(input: String): Boolean {
        var input = input
        val result = false
        input = input.lowercase(Locale.getDefault())

        //check if input is in xxx,xxx,xxx format
        if (!input.matches("[a-zA-Z]{3},[a-zA-Z]{3},[a-zA-Z]{3},[a-zA-Z]{3}".toRegex())) {
            println("Input is invalid because it is not in <xxx,xxx,xxx,xxx> format")
            return result
        }

        //remove all non letters from a string
        val justLetters = input.replace("[^a-zA-Z]".toRegex(), "")
        if (justLetters.length == 12) {

            //add all characters in the string to a set, sets contain no duplicate elements
            val testSet: MutableSet<Char> = HashSet()
            for (i in 0 until justLetters.length) {
                testSet.add(justLetters[i])
            }

            //good to go if set is the same size as the letter string
            return if (testSet.size == justLetters.length) {
                true
            } else {
                println("Input is invalid because it contains duplicate elements")
                result
            }
        }
        println("Input is invalid because is it the wrong size.")
        return result
    }

    /**
     * puts the characters into a 2d ArrayList in order to represent rows
     * @param input string of unique characters in the format xxx,xxx,xxx
     * @return 4 ArrayLists stored in a 2d ArrayList
     */
    fun convertInput(input: String): ArrayList<ArrayList<Char>>? {
        var input = input
        input = input.lowercase(Locale.getDefault())
        if (!validateInput(input)) {
            return null
        }
        val result = ArrayList<ArrayList<Char>>()
        val arrOfStrings = input.split(",".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
        for (row in arrOfStrings) {
            val chars = ArrayList<Char>()
            for (c in row.toCharArray()) {
                chars.add(c)
            }
            result.add(chars)
        }
        return result
    }
}