import java.util.*


fun main(args: Array<String>) {
    val path = "data/cleanWords.txt"
    val g = Game(path)
    val scanner = Scanner(System.`in`)
    print("Enter problem in format <xxx,xxx,xxx,xxx>: ");
    val input = scanner.nextLine()
    val start = System.currentTimeMillis()
    val result = g.playGame(input)

    for (combo in result!!) {
        println(combo?.get(0) + " " + (combo?.get(1)))
    }

    println("There are ${result.size} possible solutions");

    val ms = System.currentTimeMillis() - start
    println("Time elapsed: $ms ms.")

    scanner.close()




    scanner.close()


}