import java.io.BufferedReader
import java.io.FileReader
import java.io.IOException
import java.util.*


class ReadText {
    /**
     * Reads words from a .txt file to use in the game.
     * @param path path of the .txt file
     * @return HashMap sorted by first word.
     */
    fun read(path: String?): HashMap<Char, ArrayList<String>> {
        val result = HashMap<Char, ArrayList<String>>()
        try {
            val fr = FileReader(path)
            val br = BufferedReader(fr)
            var line = br.readLine()
            while (line != null) {
                line = line.lowercase(Locale.getDefault())
                if (line.length < 3) {
                    line = br.readLine()
                    continue
                }

                //check if line only contains letters
                if (!line.matches("[a-zA-Z]+".toRegex())) {
                    line = br.readLine()
                    continue
                }

                //check if line does not have back to back letters
                var doubleLetter = false
                for (i in 0 until line.length - 1) {
                    if (line[i] == line[i + 1]) {
                        doubleLetter = true
                    }
                }
                if (!doubleLetter) {
                    val key = line[0]

                    //computeIFAbsent returns the new or old value associated with the specified key
                    result.computeIfAbsent(
                        key
                    ) { k: Char? -> ArrayList() }.add(line)
                }
                line = br.readLine()
            }
            br.close()
            fr.close()
        } catch (e: IOException) {
            print("File Not Found")
        }
        return result
    }
}