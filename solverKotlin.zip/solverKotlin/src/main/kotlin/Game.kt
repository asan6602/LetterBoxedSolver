import java.util.*


class Game(path: String) {


    var readText: ReadText = ReadText()
    var validator: Validator = Validator()
    var fromTxt: HashMap<Char, ArrayList<String>>? = readText.read(path)

    /**
     * finds two word solutions that fits the puzzle (made up of letters within the problem, do not have consecutive letters from the same row)
     * @param input string in the format xxx,xxx,xxx,xxx where x is a unique character
     * @return an arrayList of String[] that are two word combinations that solve the game
     */
    fun playGame(input: String): ArrayList<Array<String?>?>? {

        var result: ArrayList<Array<String?>?>? = ArrayList()
        var puzzlewords: HashMap<Char?, ArrayList<String?>?>? = HashMap()
        val rows: ArrayList<ArrayList<Char?>?>? = (validator.convertInput(input) ?: return null) as ArrayList<ArrayList<Char?>?>?

        //list of characters, want to use arraylist since it has the contains method
        val justLetters = input.replace("[^a-zA-Z]".toRegex(), "").lowercase(Locale.getDefault())
        val letterArray = justLetters.toCharArray()
        val characterList = ArrayList<Char>()
        for (c in letterArray) {
            characterList.add(c)
        }
        puzzlewords = findWordsInProblem(characterList)
        puzzlewords = checkRows(rows, puzzlewords)
        result = solutions(puzzlewords, characterList)
        return result
    }

    /**
     * helper function that returns words with characters only made up of characters within the problem
     * @param characterList list of characters that make up the characters of the problem
     * @return a Hashmap made up of words only consisting of characters within the problem
     */
    fun findWordsInProblem(characterList: ArrayList<Char>): HashMap<Char?, ArrayList<String?>?>? {
        val result = HashMap<Char?, ArrayList<String?>?>()
        for (k in characterList) {
            val words = fromTxt!![k]
            val puzzleWords = ArrayList<String?>()
            if (words == null) {
                continue
            }
            for (word in words) {
                var isValidWord = true
                for (i in 0 until word.length) {
                    val c = word[i]
                    if (!characterList.contains(c)) {
                        isValidWord = false
                        break
                    }
                }
                if (isValidWord) {
                    puzzleWords.add(word)
                }
            }
            result[k] = puzzleWords
        }
        return result
    }

    /**
     * helper function that returns words that do not have consecutive letters belonging to the same row.
     * @param rows 2d ArrayList of characters that represent the rows in the game
     * @param words words to parse through
     * @return a Hashmap made up of words that do not have consecurtive letters belonging to the same row
     */
    fun checkRows(
        rows: ArrayList<ArrayList<Char?>?>?,
        words: HashMap<Char?, ArrayList<String?>?>?
    ): HashMap<Char?, ArrayList<String?>?>? {
        val result = HashMap<Char?, ArrayList<String?>?>()

        //iterating through a hashmap, for each and lambda
        if (words != null) {
            words.forEach { (key: Char?, keyWords: ArrayList<String?>?) ->
                if (keyWords != null) {
                    for (word in keyWords) {
                        var validWord = true

                        //iterate through the characters of the string
                        if (word != null) {
                            for (i in 0 until word.length - 1) {
                                var row = ArrayList<Char?>()

                                //check which row contains the letter
                                if (rows != null) {
                                    for (r in rows) {
                                        if (r != null) {
                                            if (r.contains(word[i])) {
                                                row = r
                                            }
                                        }
                                    }
                                }

                                //if the next character is within the row, then the word is not valid
                                if (row.contains(word[i + 1])) {
                                    validWord = false
                                    break
                                }
                            }
                        }
                        if (validWord) {
                            if (key != null) {
                                if (word != null) {
                                    result.computeIfAbsent(
                                        key
                                    ) { k: Char? -> ArrayList() }
                                        ?.add(word)
                                }
                            }
                        }
                    }
                }
            }
        }
        return result
    }

    /**
     * gets the two word solutions that solve the game
     * @param puzzleWords words made up of letters within the problem, do not have consecutive letters from the same row
     * @param problemCharacters all the characters tin the initial problem
     * @return an arraylist of String[] with two words that fufill the game
     */
    fun solutions(
        puzzleWords: HashMap<Char?, ArrayList<String?>?>?,
        problemCharacters: ArrayList<Char>
    ): ArrayList<Array<String?>?>? {
        val result = ArrayList<Array<String?>?>()
        if (puzzleWords != null) {
            puzzleWords.forEach { (key: Char?, keyWords: ArrayList<String?>?) ->
                if (keyWords != null) {
                    for (word1 in keyWords) {
                        val lastLetter = word1?.get(word1.length - 1)
                        val wordStartingWithLastCharacter = puzzleWords[lastLetter]!!

                        //checking words that beginng with last letter of first word
                        for (word2 in wordStartingWithLastCharacter) {
                            var valid = true
                            val combinedWord = word1 + word2
                            val combinedList = ArrayList<Char>()
                            for (characterCombined in combinedWord.toCharArray()) {
                                combinedList.add(characterCombined)
                            }

                            //check that all problemCharacters are present in the two words
                            for (characterProblem in problemCharacters) {
                                if (!combinedList.contains(characterProblem)) {
                                    valid = false
                                    break
                                }
                            }
                            if (valid) {
                                val solution = arrayOfNulls<String>(2)
                                solution[0] = word1
                                solution[1] = word2
                                result.add(solution)
                            }
                        }
                    }
                }
            }
        }
        return result
    }

}